/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.normaljavaclasses;

/**
 *
 * @author teoberbic
 */
public class TimeTracking {
//    Before you write even one line of code, create a file called “Time Tracking” and log the date and time when you
//    start a task related to this project and the time you stop. You should include a small comment to indicate what you
//    spent your time doing: planning features, brainstorming, coding features, testing, etc. Be honest with yourself, and do
//    not include time that you were half working and half looking at your phone or streaming video. 
//Feb 8 -- 9am - 11am --- doing FP1 and design initial design/UI mock ups
// Feb 13 --11:30 am - 2pm --- planning out everything in google doc & created APIRequestHanlder class and made first request from API
// Feb 13 -- 6pm - 7pm --- json to gson api request and put whole request in QuestionContainer class list and parsed each Question within the class
// Feb 14 -- 8pm - 10pm --- figuring out html characters in my json string responses and how to convert them to normal characters
// Feb 17 -- 2pm - 4pm --- Downloading and figuring out LibGDX and followin to tutorial to make a simple game to get comfortable with it
// Feb 19 -- 5pm - 6pm & 9pm - 11pm --- Advancing my knowledge in LibGDX and continuing to learn more features by applying them to the simple game like game states
// Feb 20 -- 4 - 7pm --- Establising the start game state and then working on the home screen. I implemented a wheel spinner for each player to select a category, put in each category on the wheel, and calculated where it lands and output category depending on where it lands
// Mar 13 -- 7 - 9pm --- Writing exactly what steps I need to do in google doc step by and fixing package issue
// Mar 16 -- 9am - 11am -- Figuring out how Scene2D to works, taking notes about it, planning how I would use it
// Mar 17 -- 10am - 1pm -- Getting/Implementing assets, starting CategoryPickerScreen UI and logic with Scene2D
// Mar 18 -- 2pm - 4pm -- Implementing logic of player1 entering name, picking category, getting their category assigned to them, and same for player 2
// Mar 19 -- 9am - 12 pm --
// Mar 20 -- 9am - 11am -- 
// Mar 23 -- 9am - 10am --
// Mar 24 -- 9am - 11 am --
    
}
