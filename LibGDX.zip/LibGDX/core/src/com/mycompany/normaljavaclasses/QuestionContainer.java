/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.normaljavaclasses;

//import com.mycompany.normaljavaclasses.Question;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author teoberbic
 */
public class QuestionContainer {
    private List<Question> results;
    
    public List<Question> getQuestions() {
        return results;
    }
    
    public static void Main (String[] args) {
        
    }
}
